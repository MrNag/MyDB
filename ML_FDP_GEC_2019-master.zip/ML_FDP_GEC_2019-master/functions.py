marks = 0
def greet():
    print('Hello')
