# pg2dm-python

Python code for the free book [A Programmer's Guide to Data Mining](http://guidetodatamining.com)