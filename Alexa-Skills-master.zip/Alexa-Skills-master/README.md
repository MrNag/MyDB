# Alexa-Skills
Alexa Skills with IoT and Machine Learning
