def welcome():
    print("Good Evening")
def welcomeWithName(name):
    print("Good Evening",name)