print("Hello")
print("23 + 5667 is ", 23+5667)