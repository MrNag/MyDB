# Gym envs

* cambridge_hovorka_model: https://github.com/jonasnm/gym/tree/master/gym/envs/cambridge_model
* hovorka_model: https://github.com/jonasnm/gym/tree/master/gym/envs/diabetes
* simglucose: https://github.com/jxx123/simglucose/tree/master/simglucose/envs