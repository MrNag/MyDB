# Diabetes_Prediction

Using the Decision Tree, the accuracy obtained is 87.1794% and Average precision-recall score obtained is 0.66
